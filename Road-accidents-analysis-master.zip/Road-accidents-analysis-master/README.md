# Road-accidents-analysis

This project aims, through machine learning techniques, at creation a model for road traffic accidents classifications. Dataset contains information on accidents across Leeds. Data includes location, number of people and vehicles involved, road surface, weather conditions and severity of any casualties. 
Dataset source: https://data.gov.uk/dataset/road-traffic-accidents
